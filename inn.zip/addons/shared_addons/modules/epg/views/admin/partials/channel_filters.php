<fieldset id="filters">
	<legend>FILTER</legend>

	<h2>SEARCH &amp; FILTER</h2>
	<ul>
		<li>Filter by category</li>
		<li>Search by Channel number / name</li>
	</ul>
</fieldset>