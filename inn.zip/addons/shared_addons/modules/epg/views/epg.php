<section class="title">
	<h4><?php echo 'FRONTEND' ?></h4>
</section>

<section class="item">
	<div class="content">		
		<ul>
			<li>Add channel</li>
			<li>Edit channel</li>
			<li>Add channel logo</li>
		</ul>
	</div>
</section>