<?php
//messages
$lang['epg:success']		=	'It worked';
$lang['epg:error']			=	'It didn\'t work';
$lang['epg:no_items']		=	'No Items';

//page titles
$lang['epg:create']			=	'Create Item';
$lang['epg:dashboard']		=	'Dashboard';
$lang['epg:channels']		=	'Channels Administration';
$lang['epg:shows']			=	'Shows Administration';

//labels
$lang['epg:name']			=	'Name';
$lang['epg:email']			=	'Email';
$lang['epg:manage']			=	'Manage';
$lang['epg:item_list']		=	'Item List';
$lang['epg:view']			=	'View';
$lang['epg:edit']			=	'Edit';
$lang['epg:delete']			=	'Delete';

//buttons
$lang['epg:custom_button']	=	'Custom Button';
$lang['epg:items']			=	'Items';
?>