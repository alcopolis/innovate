<?php defined('BASEPATH') OR exit('No direct script access allowed');

// titles
$lang['products:create'] = 'Add Product';
$lang['products:title'] = 'Products';

/* End of file products_lang.php */
