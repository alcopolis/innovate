<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Error 404
$lang['error_404_title'] 			= '找不到頁面';
$lang['error_404_message'] 			= '我們無法找到您要檢視的頁面，請  <a href="%s">點選這裡</a> 以回到首頁。';

// Database
$lang['error_invalid_db_group'] 	= '資料庫目前正嘗試使用的設定 "%s" 是不正確的。';
