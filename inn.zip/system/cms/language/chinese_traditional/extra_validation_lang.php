<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= "%s 欄位只能包含一般英文數字、底線、點、破折號。"; //"The %s field may only contain alpha-numeric characters, underscores, dots and dashes.";
$lang['decimal']				= "%s 欄位只能包含十進位數字"; //"The %s field must contain only decimal numbers.";
$lang['csrf_bad_token']			= "不正確的 CSRF Token"; //"Invalid CSRF Token";

/* End of file extra_validation_lang.php */