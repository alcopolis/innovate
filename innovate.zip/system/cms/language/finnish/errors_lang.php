<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Error 404
$lang['error_404_title'] = 'Sivu puuttuu';
$lang['error_404_message'] = 'Haluamaasi sivua ei löytynyt, <a href="%s">klikkaa tästä</a> mennäksesi etusivulle.';

// Database
$lang['error_invalid_db_group'] = 'Tietokanta yrittää käyttää kelpaamatonta konfigurointi ryhmää "%s".';

/* End of file errors_lang.php */