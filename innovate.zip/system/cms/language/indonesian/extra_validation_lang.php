<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= "Kolom %s hanya boleh mengandung karakter alpha-numeric, garis bawah, titik dan strip.";
$lang['decimal']				= "Kolom %s harus mengandung hanya angka desimal.";
$lang['csrf_bad_token']			= "Invalid CSRF Token"; #translate

/* End of file extra_validation_lang.php */
