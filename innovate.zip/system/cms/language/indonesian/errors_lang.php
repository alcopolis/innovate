<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Error 404
$lang['error_404_title'] = 'Halaman Hilang';
$lang['error_404_message'] = 'Kami tidak dapat menemukan halaman yang Anda maksud, silakan klik <a href="%s">disini</a> untuk kembali ke beranda.';

// Database
$lang['error_invalid_db_group'] = 'Database berusaha untuk menggunakan konfigurasi grup yang salah "%s".';

/* End of file errors_lang.php */
