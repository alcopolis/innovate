<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= "%s feltet må kun indeholde tegnene 0-9, a-z, bundstreg, punktummer og bindestreg.";
$lang['decimal']				= "%s feltet må kun indeholde decimaltal.";
$lang['csrf_bad_token']			= "Invalid CSRF Token"; #translate

/* End of file extra_validation_lang.php */